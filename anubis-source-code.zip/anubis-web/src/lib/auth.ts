import { NextRequest } from 'next/server';
import jwt from 'jsonwebtoken';

// This would be stored in an environment variable in production
const JWT_SECRET = 'anubis-community-secret-key';

interface AuthResult {
  success: boolean;
  userId?: string;
  error?: string;
}

export async function verifyAuth(request: NextRequest): Promise<AuthResult> {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return { success: false, error: 'No token provided' };
    }

    const token = authHeader.split(' ')[1];
    
    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string };
    
    return {
      success: true,
      userId: decoded.id
    };
  } catch (error) {
    console.error('Auth verification error:', error);
    return {
      success: false,
      error: 'Invalid token'
    };
  }
}
