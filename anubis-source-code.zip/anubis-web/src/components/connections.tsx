'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

interface ConnectionsProps {
  userId?: string;
}

export function Connections({ userId }: ConnectionsProps) {
  const { user, token } = useAuth();
  const [connections, setConnections] = useState<any[]>([]);
  const [pendingRequests, setPendingRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (token) {
      fetchConnections();
    }
  }, [token]);

  const fetchConnections = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/connections', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch connections');
      }
      
      // Separate connections into accepted and pending
      const accepted = data.connections.filter((conn: any) => conn.status === 'accepted');
      const pending = data.connections.filter((conn: any) => conn.status === 'pending');
      
      setConnections(accepted);
      setPendingRequests(pending);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching connections:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptConnection = async (connectionId: string) => {
    try {
      const response = await fetch(`/api/connections/${connectionId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          status: 'accepted'
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to accept connection');
      }
      
      // Update local state
      const updatedRequest = pendingRequests.find(req => req.id === connectionId);
      if (updatedRequest) {
        setConnections([...connections, {...updatedRequest, status: 'accepted'}]);
        setPendingRequests(pendingRequests.filter(req => req.id !== connectionId));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error accepting connection:', err);
    }
  };

  const handleRejectConnection = async (connectionId: string) => {
    try {
      const response = await fetch(`/api/connections/${connectionId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          status: 'rejected'
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to reject connection');
      }
      
      // Update local state
      setPendingRequests(pendingRequests.filter(req => req.id !== connectionId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error rejecting connection:', err);
    }
  };

  const handleRemoveConnection = async (connectionId: string) => {
    try {
      const response = await fetch(`/api/connections/${connectionId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to remove connection');
      }
      
      // Update local state
      setConnections(connections.filter(conn => conn.id !== connectionId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error removing connection:', err);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-2 text-muted-foreground">Loading connections...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-md">
          {error}
        </div>
      )}
      
      {pendingRequests.length > 0 && (
        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold">Connection Requests</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingRequests.map(request => (
                <div key={request.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar
                      src={request.avatar_url}
                      alt={request.display_name}
                      size="md"
                      variant="bordered"
                    />
                    <div>
                      <h4 className="font-bold">{request.display_name}</h4>
                      <p className="text-sm text-muted-foreground">@{request.username}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      onClick={() => handleAcceptConnection(request.id)}
                    >
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRejectConnection(request.id)}
                    >
                      Decline
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      <Card>
        <CardHeader>
          <h3 className="text-xl font-bold">Friends</h3>
        </CardHeader>
        <CardContent>
          {connections.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              No connections yet. Start connecting with other users!
            </p>
          ) : (
            <div className="space-y-4">
              {connections.map(connection => (
                <div key={connection.id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar
                      src={connection.avatar_url}
                      alt={connection.display_name}
                      size="md"
                      variant="bordered"
                    />
                    <div>
                      <h4 className="font-bold">{connection.display_name}</h4>
                      <p className="text-sm text-muted-foreground">@{connection.username}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRemoveConnection(connection.id)}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
