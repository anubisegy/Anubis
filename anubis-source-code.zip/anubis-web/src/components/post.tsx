'use client';

import React, { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';

interface PostProps {
  post: {
    id: string;
    content: string;
    imageUrl?: string;
    createdAt: number;
    userId: string;
    username: string;
    displayName: string;
    avatarUrl?: string;
    likesCount: number;
    commentsCount: number;
  };
  onLike?: (postId: string, liked: boolean) => void;
  onComment?: (postId: string) => void;
  onShare?: (postId: string) => void;
}

export function Post({ post, onLike, onComment, onShare }: PostProps) {
  const { token } = useAuth();
  const [isLiking, setIsLiking] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [commentContent, setCommentContent] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  
  const handleLike = async () => {
    if (isLiking || !token) return;
    
    setIsLiking(true);
    
    try {
      const response = await fetch(`/api/posts/${post.id}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok) {
        const newLiked = data.liked;
        setLiked(newLiked);
        setLikesCount(prev => newLiked ? prev + 1 : prev - 1);
        
        if (onLike) {
          onLike(post.id, newLiked);
        }
      }
    } catch (error) {
      console.error('Error liking post:', error);
    } finally {
      setIsLiking(false);
    }
  };
  
  const loadComments = async () => {
    if (!token) return;
    
    try {
      const response = await fetch(`/api/posts/${post.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (response.ok && data.comments) {
        setComments(data.comments);
      }
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  };
  
  const handleToggleComments = () => {
    const newShowComments = !showComments;
    setShowComments(newShowComments);
    
    if (newShowComments && comments.length === 0) {
      loadComments();
    }
    
    if (onComment) {
      onComment(post.id);
    }
  };
  
  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!commentContent.trim() || isSubmittingComment || !token) return;
    
    setIsSubmittingComment(true);
    
    try {
      const response = await fetch(`/api/posts/${post.id}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          content: commentContent
        })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setComments(prev => [...prev, data.comment]);
        setCommentContent('');
      }
    } catch (error) {
      console.error('Error submitting comment:', error);
    } finally {
      setIsSubmittingComment(false);
    }
  };
  
  const handleShare = () => {
    if (onShare) {
      onShare(post.id);
    }
  };
  
  const formattedDate = formatDistanceToNow(new Date(post.createdAt * 1000), { addSuffix: true });
  
  return (
    <Card className="anubis-card mb-6">
      <CardHeader className="pb-2">
        <div className="flex items-center">
          <Avatar
            src={post.avatarUrl}
            alt={post.displayName}
            size="md"
            variant="bordered"
          />
          <div className="ml-3">
            <h4 className="font-bold text-foreground">{post.displayName}</h4>
            <p className="text-xs text-muted-foreground">
              {post.username} • {formattedDate}
            </p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="py-2">
        {post.content && (
          <p className="text-foreground mb-4">{post.content}</p>
        )}
        
        {post.imageUrl && (
          <div className="rounded-md overflow-hidden border border-border mb-4">
            <img src={post.imageUrl} alt="Post content" className="w-full h-auto" />
          </div>
        )}
      </CardContent>
      
      <CardFooter className="pt-2 flex flex-col">
        <div className="flex items-center justify-between w-full border-t border-border pt-3">
          <button
            className={`flex items-center text-muted-foreground hover:text-primary ${liked ? 'text-primary' : ''}`}
            onClick={handleLike}
            disabled={isLiking}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill={liked ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <span>{likesCount}</span>
          </button>
          
          <button
            className="flex items-center text-muted-foreground hover:text-primary"
            onClick={handleToggleComments}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <span>{post.commentsCount}</span>
          </button>
          
          <button
            className="flex items-center text-muted-foreground hover:text-primary"
            onClick={handleShare}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
            <span>Share</span>
          </button>
        </div>
        
        {showComments && (
          <div className="w-full mt-4">
            {comments.map(comment => (
              <div key={comment.id} className="flex items-start space-x-3 mb-3">
                <Avatar
                  src={comment.avatarUrl}
                  alt={comment.displayName}
                  size="sm"
                  variant="bordered"
                />
                <div className="flex-1 bg-muted p-3 rounded-md">
                  <div className="flex justify-between items-start">
                    <h5 className="font-bold text-sm">{comment.displayName}</h5>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(comment.createdAt * 1000), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-sm mt-1">{comment.content}</p>
                </div>
              </div>
            ))}
            
            <form onSubmit={handleSubmitComment} className="mt-3">
              <div className="flex space-x-2">
                <input
                  type="text"
                  className="flex-1 p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Write a comment..."
                  value={commentContent}
                  onChange={(e) => setCommentContent(e.target.value)}
                />
                <Button
                  type="submit"
                  size="sm"
                  disabled={!commentContent.trim() || isSubmittingComment}
                >
                  {isSubmittingComment ? 'Sending...' : 'Send'}
                </Button>
              </div>
            </form>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}
