import React from 'react';
import { cn } from '@/lib/utils';

interface MainLayoutProps {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
  header?: React.ReactNode;
}

export function MainLayout({ children, sidebar, header }: MainLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col papyrus-bg">
      {header && (
        <header className="sticky top-0 z-10 w-full">{header}</header>
      )}
      <div className="flex flex-1 overflow-hidden">
        {sidebar && (
          <aside className="hidden md:block">{sidebar}</aside>
        )}
        <main className="flex-1 overflow-auto p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}

interface ContentContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'narrow' | 'wide';
}

const ContentContainer = React.forwardRef<HTMLDivElement, ContentContainerProps>(
  ({ className, variant = 'default', ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'mx-auto bg-card rounded-lg shadow-md p-6',
          {
            'max-w-3xl': variant === 'default',
            'max-w-xl': variant === 'narrow',
            'max-w-5xl': variant === 'wide',
          },
          className
        )}
        {...props}
      />
    );
  }
);
ContentContainer.displayName = 'ContentContainer';

interface PageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}

const PageHeader = React.forwardRef<HTMLDivElement, PageHeaderProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('mb-8', className)}
        {...props}
      />
    );
  }
);
PageHeader.displayName = 'PageHeader';

interface PageTitleProps extends React.HTMLAttributes<HTMLHeadingElement> {}

const PageTitle = React.forwardRef<HTMLHeadingElement, PageTitleProps>(
  ({ className, ...props }, ref) => {
    return (
      <h1
        ref={ref}
        className={cn(
          'text-3xl font-bold tracking-tight text-primary font-cinzel',
          className
        )}
        {...props}
      />
    );
  }
);
PageTitle.displayName = 'PageTitle';

interface PageDescriptionProps extends React.HTMLAttributes<HTMLParagraphElement> {}

const PageDescription = React.forwardRef<HTMLParagraphElement, PageDescriptionProps>(
  ({ className, ...props }, ref) => {
    return (
      <p
        ref={ref}
        className={cn('text-muted-foreground mt-2', className)}
        {...props}
      />
    );
  }
);
PageDescription.displayName = 'PageDescription';

export { ContentContainer, PageHeader, PageTitle, PageDescription };
