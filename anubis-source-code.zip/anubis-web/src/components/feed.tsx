'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { CreatePost } from '@/components/create-post';
import { Post } from '@/components/post';
import { StoriesContainer, StoryCard } from '@/components/ui/story-card';

interface FeedProps {
  userId?: string;
}

export function Feed({ userId }: FeedProps) {
  const { token } = useAuth();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stories, setStories] = useState([
    { id: '1', username: 'amunet', avatar: '/images/avatars/amunet.jpg', active: true },
    { id: '2', username: 'ramses', avatar: '/images/avatars/ramses.jpg', active: true },
    { id: '3', username: 'nefertiti', avatar: '/images/avatars/nefertiti.jpg', active: true },
    { id: '4', username: 'tutankhamun', avatar: '/images/avatars/tutankhamun.jpg', active: false },
    { id: '5', username: 'cleopatra', avatar: '/images/avatars/cleopatra.jpg', active: true },
  ]);

  useEffect(() => {
    fetchPosts();
  }, [userId, token]);

  const fetchPosts = async () => {
    if (!token) return;
    
    setLoading(true);
    setError('');
    
    try {
      const url = new URL('/api/posts', window.location.origin);
      
      if (userId) {
        url.searchParams.append('userId', userId);
      }
      
      const response = await fetch(url.toString(), {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch posts');
      }
      
      setPosts(data.posts || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching posts:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePostCreated = (newPost: any) => {
    setPosts(prev => [newPost, ...prev]);
  };

  const handleLike = (postId: string, liked: boolean) => {
    // Update local state to reflect like status
    setPosts(prev => 
      prev.map(post => 
        post.id === postId 
          ? { ...post, likesCount: liked ? post.likesCount + 1 : post.likesCount - 1 } 
          : post
      )
    );
  };

  return (
    <div className="max-w-2xl mx-auto">
      <StoriesContainer className="flex space-x-4">
        {stories.map(story => (
          <StoryCard 
            key={story.id}
            username={story.username}
            avatar={story.avatar}
            active={story.active}
          />
        ))}
      </StoriesContainer>
      
      <CreatePost onPostCreated={handlePostCreated} />
      
      {error && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-md mb-6">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <p className="mt-2 text-muted-foreground">Loading posts...</p>
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No posts found.</p>
        </div>
      ) : (
        <div>
          {posts.map(post => (
            <Post 
              key={post.id} 
              post={post} 
              onLike={handleLike}
            />
          ))}
        </div>
      )}
    </div>
  );
}
