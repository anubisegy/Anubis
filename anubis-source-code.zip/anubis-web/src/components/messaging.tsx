'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Card, CardHeader, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';

interface MessagingProps {
  recipientId?: string;
}

export function Messaging({ recipientId }: MessagingProps) {
  const { user, token } = useAuth();
  const [conversations, setConversations] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [activeRecipient, setActiveRecipient] = useState<any>(null);
  const [messageContent, setMessageContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (token) {
      fetchConversations();
      
      if (recipientId) {
        handleSelectConversation(recipientId);
      }
    }
  }, [token, recipientId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchConversations = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/messages', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch conversations');
      }
      
      setConversations(data.messages || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching conversations:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (otherUserId: string) => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`/api/messages?recipientId=${otherUserId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch messages');
      }
      
      setMessages(data.messages || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching messages:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectConversation = async (otherUserId: string) => {
    // Find the conversation partner
    const conversation = conversations.find(
      conv => 
        (conv.sender_id === otherUserId && conv.recipient_id === user?.id) || 
        (conv.sender_id === user?.id && conv.recipient_id === otherUserId)
    );
    
    if (conversation) {
      const isUserSender = conversation.sender_id === user?.id;
      setActiveRecipient({
        id: isUserSender ? conversation.recipient_id : conversation.sender_id,
        username: isUserSender ? conversation.recipient_username : conversation.sender_username,
        displayName: isUserSender ? conversation.recipient_display_name : conversation.sender_display_name,
        avatarUrl: isUserSender ? conversation.recipient_avatar_url : conversation.sender_avatar_url
      });
    } else if (otherUserId) {
      // If we don't have a conversation yet but have a recipient ID, fetch user info
      try {
        const response = await fetch(`/api/users/${otherUserId}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        const data = await response.json();
        
        if (response.ok) {
          setActiveRecipient({
            id: data.user.id,
            username: data.user.username,
            displayName: data.user.display_name,
            avatarUrl: data.user.avatar_url
          });
        }
      } catch (err) {
        console.error('Error fetching recipient info:', err);
      }
    }
    
    // Fetch messages for this conversation
    await fetchMessages(otherUserId);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageContent.trim() || !activeRecipient || !token) return;
    
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          recipientId: activeRecipient.id,
          content: messageContent
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to send message');
      }
      
      // Add new message to the list
      setMessages(prev => [data.messageData, ...prev]);
      
      // Clear input
      setMessageContent('');
      
      // Update conversations list
      fetchConversations();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error sending message:', err);
    }
  };

  if (loading && !conversations.length && !messages.length) {
    return (
      <div className="text-center py-8">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-2 text-muted-foreground">Loading messages...</p>
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-200px)] overflow-hidden rounded-lg border border-border">
      {/* Conversations sidebar */}
      <div className="w-1/3 border-r border-border bg-muted/30">
        <div className="p-4 border-b border-border">
          <h3 className="font-bold text-lg">Messages</h3>
        </div>
        <div className="overflow-y-auto h-[calc(100%-60px)]">
          {conversations.length === 0 ? (
            <p className="text-center text-muted-foreground p-4">
              No conversations yet
            </p>
          ) : (
            conversations.map(conv => {
              const isUserSender = conv.sender_id === user?.id;
              const otherUserId = isUserSender ? conv.recipient_id : conv.sender_id;
              const otherUserName = isUserSender ? conv.recipient_display_name : conv.sender_display_name;
              const otherUserAvatar = isUserSender ? conv.recipient_avatar_url : conv.sender_avatar_url;
              const isActive = activeRecipient?.id === otherUserId;
              
              return (
                <div 
                  key={conv.id}
                  className={`p-3 border-b border-border cursor-pointer hover:bg-muted transition-colors ${isActive ? 'bg-muted' : ''}`}
                  onClick={() => handleSelectConversation(otherUserId)}
                >
                  <div className="flex items-center space-x-3">
                    <Avatar
                      src={otherUserAvatar}
                      alt={otherUserName}
                      size="md"
                      variant="bordered"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h4 className="font-bold truncate">{otherUserName}</h4>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(conv.created_at * 1000), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {isUserSender ? 'You: ' : ''}{conv.content}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
      
      {/* Message area */}
      <div className="flex-1 flex flex-col">
        {activeRecipient ? (
          <>
            <div className="p-4 border-b border-border bg-muted/30">
              <div className="flex items-center space-x-3">
                <Avatar
                  src={activeRecipient.avatarUrl}
                  alt={activeRecipient.displayName}
                  size="md"
                  variant="bordered"
                />
                <div>
                  <h4 className="font-bold">{activeRecipient.displayName}</h4>
                  <p className="text-sm text-muted-foreground">@{activeRecipient.username}</p>
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 flex flex-col-reverse">
              <div ref={messagesEndRef} />
              {messages.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">
                  No messages yet. Start the conversation!
                </p>
              ) : (
                messages.map(msg => {
                  const isUserSender = msg.sender_id === user?.id;
                  
                  return (
                    <div 
                      key={msg.id}
                      className={`mb-4 flex ${isUserSender ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isUserSender && (
                        <Avatar
                          src={msg.sender_avatar_url}
                          alt={msg.sender_display_name}
                          size="sm"
                          variant="bordered"
                          className="mr-2 mt-1"
                        />
                      )}
                      <div 
                        className={`max-w-[70%] p-3 rounded-lg ${
                          isUserSender 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}
                      >
                        <p>{msg.content}</p>
                        <p className={`text-xs mt-1 ${isUserSender ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                          {formatDistanceToNow(new Date(msg.created_at * 1000), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
            
            <div className="p-4 border-t border-border">
              <form onSubmit={handleSendMessage} className="flex space-x-2">
                <input
                  type="text"
                  className="flex-1 p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Type a message..."
                  value={messageContent}
                  onChange={(e) => setMessageContent(e.target.value)}
                />
                <Button
                  type="submit"
                  disabled={!messageContent.trim()}
                >
                  Send
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <p>Select a conversation to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
