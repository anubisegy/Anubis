'use client';

import React, { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';

interface CreatePostProps {
  onPostCreated?: (post: any) => void;
}

export function CreatePost({ onPostCreated }: CreatePostProps) {
  const { user, token } = useAuth();
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [visibility, setVisibility] = useState('public');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content && !imageUrl) {
      setError('Post must contain content or image');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          content,
          imageUrl,
          visibility
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create post');
      }
      
      // Reset form
      setContent('');
      setImageUrl('');
      
      // Notify parent component
      if (onPostCreated) {
        onPostCreated(data.post);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!user) {
    return null;
  }
  
  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        {error && (
          <div className="bg-destructive/10 text-destructive p-3 rounded-md mb-4">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="flex items-start space-x-4">
            <Avatar
              src={user.avatar}
              alt={user.displayName}
              size="md"
              variant="bordered"
            />
            <div className="flex-1">
              <textarea
                className="w-full p-3 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary resize-none min-h-[100px]"
                placeholder={`What's on your mind, ${user.displayName}?`}
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
              
              <div className="mt-2">
                <input
                  type="text"
                  className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Image URL (optional)"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                />
              </div>
              
              <div className="mt-4 flex items-center justify-between">
                <select
                  className="p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  value={visibility}
                  onChange={(e) => setVisibility(e.target.value)}
                >
                  <option value="public">Public</option>
                  <option value="friends">Friends Only</option>
                  <option value="private">Private</option>
                </select>
                
                <Button
                  type="submit"
                  disabled={isSubmitting || (!content && !imageUrl)}
                >
                  {isSubmitting ? 'Posting...' : 'Post'}
                </Button>
              </div>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
