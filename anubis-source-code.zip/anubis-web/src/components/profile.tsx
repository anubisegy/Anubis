'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Avatar } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Feed } from '@/components/feed';
import { formatDistanceToNow } from 'date-fns';

interface ProfileProps {
  userId?: string;
}

export function Profile({ userId }: ProfileProps) {
  const { user, token } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    displayName: '',
    bio: '',
    location: '',
    interests: '',
    website: ''
  });

  useEffect(() => {
    fetchProfile();
  }, [userId, token]);

  const fetchProfile = async () => {
    if (!token) return;
    
    setLoading(true);
    setError('');
    
    try {
      // If no userId is provided, fetch the current user's profile
      const profileId = userId || 'profile';
      
      const response = await fetch(`/api/auth/${profileId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch profile');
      }
      
      setProfile(data.user);
      setFormData({
        displayName: data.user.displayName || '',
        bio: data.user.bio || '',
        location: data.user.profile?.location || '',
        interests: data.user.profile?.interests || '',
        website: data.user.profile?.website || ''
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error fetching profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!token) return;
    
    try {
      const response = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          displayName: formData.displayName,
          bio: formData.bio,
          location: formData.location,
          interests: formData.interests,
          website: formData.website
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to update profile');
      }
      
      setProfile(prev => ({
        ...prev,
        displayName: formData.displayName,
        bio: formData.bio,
        profile: {
          ...prev.profile,
          location: formData.location,
          interests: formData.interests,
          website: formData.website
        }
      }));
      
      setIsEditing(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      console.error('Error updating profile:', err);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-2 text-muted-foreground">Loading profile...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-destructive/10 text-destructive p-4 rounded-md">
        {error}
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Profile not found.</p>
      </div>
    );
  }

  const isOwnProfile = !userId || (user && user.id === profile.id);
  const joinedDate = formatDistanceToNow(new Date(profile.createdAt * 1000), { addSuffix: true });

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-6">
        <CardHeader className="relative pb-0">
          <div className="h-32 bg-gradient-to-r from-primary via-accent to-secondary rounded-t-lg"></div>
          <div className="absolute -bottom-12 left-6">
            <Avatar
              src={profile.avatarUrl}
              alt={profile.displayName}
              size="xl"
              variant="bordered"
            />
          </div>
          {isOwnProfile && (
            <div className="absolute top-4 right-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(!isEditing)}
              >
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </Button>
            </div>
          )}
        </CardHeader>
        <CardContent className="pt-16">
          {isEditing ? (
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="displayName" className="block text-sm font-medium mb-1">
                    Display Name
                  </label>
                  <input
                    id="displayName"
                    name="displayName"
                    type="text"
                    value={formData.displayName}
                    onChange={handleChange}
                    className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                
                <div>
                  <label htmlFor="bio" className="block text-sm font-medium mb-1">
                    Bio
                  </label>
                  <textarea
                    id="bio"
                    name="bio"
                    value={formData.bio}
                    onChange={handleChange}
                    rows={3}
                    className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium mb-1">
                    Location
                  </label>
                  <input
                    id="location"
                    name="location"
                    type="text"
                    value={formData.location}
                    onChange={handleChange}
                    className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                
                <div>
                  <label htmlFor="interests" className="block text-sm font-medium mb-1">
                    Interests
                  </label>
                  <input
                    id="interests"
                    name="interests"
                    type="text"
                    value={formData.interests}
                    onChange={handleChange}
                    className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                
                <div>
                  <label htmlFor="website" className="block text-sm font-medium mb-1">
                    Website
                  </label>
                  <input
                    id="website"
                    name="website"
                    type="text"
                    value={formData.website}
                    onChange={handleChange}
                    className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button type="submit">
                    Save Changes
                  </Button>
                </div>
              </div>
            </form>
          ) : (
            <div>
              <h2 className="text-2xl font-bold">{profile.displayName}</h2>
              <p className="text-muted-foreground">@{profile.username}</p>
              
              {profile.bio && (
                <p className="mt-4">{profile.bio}</p>
              )}
              
              <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                <div>Joined {joinedDate}</div>
                
                {profile.profile?.location && (
                  <div>
                    <span className="mr-1">📍</span>
                    {profile.profile.location}
                  </div>
                )}
                
                {profile.profile?.website && (
                  <div>
                    <span className="mr-1">🔗</span>
                    <a href={profile.profile.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      {profile.profile.website.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                )}
              </div>
              
              {profile.profile?.interests && (
                <div className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Interests</h3>
                  <div className="flex flex-wrap gap-2">
                    {profile.profile.interests.split(',').map((interest: string, index: number) => (
                      <span key={index} className="px-3 py-1 bg-muted rounded-full text-xs">
                        {interest.trim()}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <h3 className="text-xl font-bold mb-4">Posts</h3>
        <Feed userId={profile.id} />
      </div>
    </div>
  );
}
