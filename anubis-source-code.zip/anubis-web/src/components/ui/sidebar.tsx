import React from 'react';
import { cn } from '@/lib/utils';

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

const Sidebar = React.forwardRef<HTMLDivElement, SidebarProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'w-64 h-screen bg-sidebar-background text-sidebar-foreground border-r border-border flex flex-col',
          className
        )}
        {...props}
      />
    );
  }
);
Sidebar.displayName = 'Sidebar';

interface SidebarHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarHeader = React.forwardRef<HTMLDivElement, SidebarHeaderProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('p-4 border-b border-border', className)}
        {...props}
      />
    );
  }
);
SidebarHeader.displayName = 'SidebarHeader';

interface SidebarNavProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarNav = React.forwardRef<HTMLDivElement, SidebarNavProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('p-2 flex-1 overflow-auto', className)}
        {...props}
      />
    );
  }
);
SidebarNav.displayName = 'SidebarNav';

interface SidebarItemProps extends React.HTMLAttributes<HTMLAnchorElement> {
  active?: boolean;
  icon?: React.ReactNode;
}

const SidebarItem = React.forwardRef<HTMLAnchorElement, SidebarItemProps>(
  ({ className, active, icon, children, ...props }, ref) => {
    return (
      <a
        ref={ref}
        className={cn(
          'flex items-center space-x-3 px-3 py-2 rounded-md transition-colors',
          {
            'bg-sidebar-accent text-sidebar-accent-foreground': active,
            'hover:bg-sidebar-accent/50 text-sidebar-foreground': !active,
          },
          className
        )}
        {...props}
      >
        {icon && <span className="text-sidebar-primary">{icon}</span>}
        <span>{children}</span>
      </a>
    );
  }
);
SidebarItem.displayName = 'SidebarItem';

interface SidebarFooterProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarFooter = React.forwardRef<HTMLDivElement, SidebarFooterProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('p-4 border-t border-border', className)}
        {...props}
      />
    );
  }
);
SidebarFooter.displayName = 'SidebarFooter';

export { Sidebar, SidebarHeader, SidebarNav, SidebarItem, SidebarFooter };
