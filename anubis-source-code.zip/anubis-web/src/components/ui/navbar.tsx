import React from 'react';
import { cn } from '@/lib/utils';

interface NavbarProps extends React.HTMLAttributes<HTMLElement> {
  variant?: 'default' | 'transparent';
}

const Navbar = React.forwardRef<HTMLElement, NavbarProps>(
  ({ className, variant = 'default', ...props }, ref) => {
    return (
      <nav
        ref={ref}
        className={cn(
          'w-full py-4 px-6 flex items-center justify-between',
          {
            'bg-background border-b border-border': variant === 'default',
            'bg-transparent': variant === 'transparent',
          },
          className
        )}
        {...props}
      />
    );
  }
);
Navbar.displayName = 'Navbar';

interface NavbarBrandProps extends React.HTMLAttributes<HTMLDivElement> {}

const NavbarBrand = React.forwardRef<HTMLDivElement, NavbarBrandProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('flex items-center space-x-2', className)}
        {...props}
      />
    );
  }
);
NavbarBrand.displayName = 'NavbarBrand';

interface NavbarLinksProps extends React.HTMLAttributes<HTMLDivElement> {}

const NavbarLinks = React.forwardRef<HTMLDivElement, NavbarLinksProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('hidden md:flex items-center space-x-6', className)}
        {...props}
      />
    );
  }
);
NavbarLinks.displayName = 'NavbarLinks';

interface NavbarLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  active?: boolean;
}

const NavbarLink = React.forwardRef<HTMLAnchorElement, NavbarLinkProps>(
  ({ className, active, ...props }, ref) => {
    return (
      <a
        ref={ref}
        className={cn(
          'text-foreground hover:text-primary transition-colors relative',
          {
            'text-primary font-medium after:absolute after:bottom-[-8px] after:left-0 after:right-0 after:h-[3px] after:bg-primary': active,
          },
          className
        )}
        {...props}
      />
    );
  }
);
NavbarLink.displayName = 'NavbarLink';

interface NavbarActionsProps extends React.HTMLAttributes<HTMLDivElement> {}

const NavbarActions = React.forwardRef<HTMLDivElement, NavbarActionsProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn('flex items-center space-x-4', className)}
        {...props}
      />
    );
  }
);
NavbarActions.displayName = 'NavbarActions';

export { Navbar, NavbarBrand, NavbarLinks, NavbarLink, NavbarActions };
