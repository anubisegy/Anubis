import React from 'react';
import { cn } from '@/lib/utils';

interface StoryCardProps extends React.HTMLAttributes<HTMLDivElement> {
  username: string;
  avatar?: string;
  active?: boolean;
}

const StoryCard = React.forwardRef<HTMLDivElement, StoryCardProps>(
  ({ className, username, avatar, active = false, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'flex flex-col items-center space-y-1 cursor-pointer transition-transform hover:scale-105',
          className
        )}
        {...props}
      >
        <div className={cn(
          'relative rounded-full p-0.5',
          active ? 'bg-gradient-to-tr from-primary via-accent to-secondary' : 'bg-muted'
        )}>
          <div className="relative overflow-hidden h-16 w-16 rounded-full border-2 border-background">
            {avatar ? (
              <img
                src={avatar}
                alt={username}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-muted text-muted-foreground">
                {username.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
        </div>
        <span className="text-xs text-center font-medium truncate max-w-[80px]">
          {username}
        </span>
      </div>
    );
  }
);
StoryCard.displayName = 'StoryCard';

interface StoriesContainerProps extends React.HTMLAttributes<HTMLDivElement> {}

const StoriesContainer = React.forwardRef<HTMLDivElement, StoriesContainerProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          'hieroglyphic-border w-full py-4 px-2 mb-6 overflow-x-auto',
          className
        )}
        {...props}
      />
    );
  }
);
StoriesContainer.displayName = 'StoriesContainer';

export { StoryCard, StoriesContainer };
