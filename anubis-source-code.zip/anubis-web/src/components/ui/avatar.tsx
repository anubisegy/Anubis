import React from 'react';
import { cn } from '@/lib/utils';

interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  src?: string;
  alt?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'default' | 'bordered' | 'cartouche';
}

const Avatar = React.forwardRef<HTMLDivElement, AvatarProps>(
  ({ className, src, alt, size = 'md', variant = 'default', ...props }, ref) => {
    const sizeClasses = {
      sm: 'h-8 w-8',
      md: 'h-10 w-10',
      lg: 'h-14 w-14',
      xl: 'h-20 w-20',
    };

    const variantClasses = {
      default: 'rounded-full',
      bordered: 'rounded-full border-2 border-primary',
      cartouche: 'rounded-full border-2 border-primary p-0.5 bg-background',
    };

    return (
      <div
        ref={ref}
        className={cn(
          'relative overflow-hidden',
          sizeClasses[size],
          variantClasses[variant],
          className
        )}
        {...props}
      >
        {src ? (
          <img
            src={src}
            alt={alt || 'Avatar'}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-muted text-muted-foreground">
            {alt ? alt.charAt(0).toUpperCase() : 'A'}
          </div>
        )}
        {variant === 'cartouche' && (
          <div className="absolute inset-0 border-2 border-primary rounded-full pointer-events-none" />
        )}
      </div>
    );
  }
);
Avatar.displayName = 'Avatar';

export { Avatar };
