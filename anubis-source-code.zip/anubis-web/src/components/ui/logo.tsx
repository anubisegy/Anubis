import React from 'react';
import { cn } from '@/lib/utils';

interface LogoProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'light' | 'dark';
}

const Logo = React.forwardRef<HTMLDivElement, LogoProps>(
  ({ className, size = 'md', variant = 'default', ...props }, ref) => {
    const sizeClasses = {
      sm: 'text-xl',
      md: 'text-2xl',
      lg: 'text-4xl',
    };

    const variantClasses = {
      default: 'text-primary',
      light: 'text-white',
      dark: 'text-foreground',
    };

    return (
      <div
        ref={ref}
        className={cn(
          'font-cinzel font-bold flex items-center',
          sizeClasses[size],
          variantClasses[variant],
          className
        )}
        {...props}
      >
        <span className="mr-1">
          {/* Ankh symbol */}
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="inline-block h-8 w-8"
          >
            <path d="M12 2v7" />
            <circle cx="12" cy="11" r="2" />
            <path d="M12 13v9" />
            <path d="M8 17h8" />
          </svg>
        </span>
        Anubis
      </div>
    );
  }
);
Logo.displayName = 'Logo';

export { Logo };
