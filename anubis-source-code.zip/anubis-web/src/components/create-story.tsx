'use client';

import React, { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar } from '@/components/ui/avatar';

interface CreateStoryProps {
  onStoryCreated?: (story: any) => void;
}

export function CreateStory({ onStoryCreated }: CreateStoryProps) {
  const { user, token } = useAuth();
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content && !imageUrl) {
      setError('Story must contain content or image');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      const response = await fetch('/api/stories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          content,
          imageUrl
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create story');
      }
      
      // Reset form
      setContent('');
      setImageUrl('');
      setIsOpen(false);
      
      // Notify parent component
      if (onStoryCreated) {
        onStoryCreated(data.story);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (!user) {
    return null;
  }
  
  return (
    <>
      <div className="mb-4">
        <Button 
          onClick={() => setIsOpen(true)}
          variant="outline"
          className="w-full"
        >
          Create Story
        </Button>
      </div>
      
      {isOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <Card className="w-full max-w-md mx-auto">
            <CardContent className="pt-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Create Story</h3>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setIsOpen(false)}
                >
                  ✕
                </Button>
              </div>
              
              {error && (
                <div className="bg-destructive/10 text-destructive p-3 rounded-md mb-4">
                  {error}
                </div>
              )}
              
              <form onSubmit={handleSubmit}>
                <div className="flex items-start space-x-4">
                  <Avatar
                    src={user.avatar}
                    alt={user.displayName}
                    size="md"
                    variant="bordered"
                  />
                  <div className="flex-1">
                    <textarea
                      className="w-full p-3 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary resize-none min-h-[100px]"
                      placeholder="Share a moment..."
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                    />
                    
                    <div className="mt-2">
                      <input
                        type="text"
                        className="w-full p-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Image URL (optional)"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                      />
                    </div>
                    
                    <div className="mt-4 flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">
                        Stories disappear after 24 hours
                      </p>
                      
                      <Button
                        type="submit"
                        disabled={isSubmitting || (!content && !imageUrl)}
                      >
                        {isSubmitting ? 'Posting...' : 'Share Story'}
                      </Button>
                    </div>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
