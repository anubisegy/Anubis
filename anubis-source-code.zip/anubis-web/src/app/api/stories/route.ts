import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Get query parameters
    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');
    
    // Construct query
    let query = `
      SELECT s.*, u.username, u.display_name, u.avatar_url
      FROM stories s
      JOIN users u ON s.user_id = u.id
      WHERE s.expires_at > ?
    `;
    
    const queryParams = [Math.floor(Date.now() / 1000)];
    
    // Filter by user if provided
    if (userId) {
      query += ` AND s.user_id = ?`;
      queryParams.push(userId);
    }
    
    // Add ordering
    query += ` ORDER BY s.created_at DESC`;
    
    // Execute query
    const stories = await env.DB.prepare(query)
      .bind(...queryParams)
      .all();
    
    return NextResponse.json({ stories: stories.results });
  } catch (error) {
    console.error('Get stories error:', error);
    return NextResponse.json(
      { error: 'Failed to get stories' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const { content, imageUrl } = await request.json();
    
    // Validate input
    if (!content && !imageUrl) {
      return NextResponse.json(
        { error: 'Story must contain content or image' },
        { status: 400 }
      );
    }
    
    // Create story
    const storyId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    const expiresAt = timestamp + 86400; // 24 hours from now
    
    await env.DB.prepare(
      'INSERT INTO stories (id, user_id, content, image_url, expires_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
      .bind(storyId, userId, content, imageUrl, expiresAt, timestamp, timestamp)
      .run();
    
    // Get user info
    const user = await env.DB.prepare(
      'SELECT username, display_name, avatar_url FROM users WHERE id = ?'
    )
      .bind(userId)
      .first();
    
    return NextResponse.json({
      message: 'Story created successfully',
      story: {
        id: storyId,
        userId,
        content,
        imageUrl,
        expiresAt,
        createdAt: timestamp,
        updatedAt: timestamp,
        username: user.username,
        displayName: user.display_name,
        avatarUrl: user.avatar_url
      }
    }, { status: 201 });
  } catch (error) {
    console.error('Create story error:', error);
    return NextResponse.json(
      { error: 'Failed to create story' },
      { status: 500 }
    );
  }
}
