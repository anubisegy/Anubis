import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    
    // Get query parameters
    const url = new URL(request.url);
    const recipientId = url.searchParams.get('recipientId');
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const offset = parseInt(url.searchParams.get('offset') || '0');
    
    let query = '';
    let queryParams = [];
    
    if (recipientId) {
      // Get conversation between two users
      query = `
        SELECT m.*, 
               sender.username as sender_username, 
               sender.display_name as sender_display_name, 
               sender.avatar_url as sender_avatar_url
        FROM messages m
        JOIN users sender ON m.sender_id = sender.id
        WHERE (m.sender_id = ? AND m.recipient_id = ?) OR (m.sender_id = ? AND m.recipient_id = ?)
        ORDER BY m.created_at DESC
        LIMIT ? OFFSET ?
      `;
      queryParams = [userId, recipientId, recipientId, userId, limit, offset];
    } else {
      // Get all conversations for the user
      query = `
        SELECT 
          m.*,
          sender.username as sender_username,
          sender.display_name as sender_display_name,
          sender.avatar_url as sender_avatar_url,
          recipient.username as recipient_username,
          recipient.display_name as recipient_display_name,
          recipient.avatar_url as recipient_avatar_url
        FROM messages m
        JOIN users sender ON m.sender_id = sender.id
        JOIN users recipient ON m.recipient_id = recipient.id
        WHERE m.id IN (
          SELECT MAX(id) FROM messages
          WHERE sender_id = ? OR recipient_id = ?
          GROUP BY 
            CASE 
              WHEN sender_id = ? THEN recipient_id 
              ELSE sender_id 
            END
        )
        ORDER BY m.created_at DESC
      `;
      queryParams = [userId, userId, userId];
    }
    
    const messages = await env.DB.prepare(query)
      .bind(...queryParams)
      .all();
    
    // If getting a specific conversation, mark messages as read
    if (recipientId) {
      await env.DB.prepare(
        'UPDATE messages SET read = 1 WHERE sender_id = ? AND recipient_id = ? AND read = 0'
      )
        .bind(recipientId, userId)
        .run();
    }
    
    return NextResponse.json({ messages: messages.results });
  } catch (error) {
    console.error('Get messages error:', error);
    return NextResponse.json(
      { error: 'Failed to get messages' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const { recipientId, content } = await request.json();
    
    // Validate input
    if (!recipientId || !content) {
      return NextResponse.json(
        { error: 'Recipient ID and content are required' },
        { status: 400 }
      );
    }
    
    // Check if recipient exists
    const recipient = await env.DB.prepare(
      'SELECT * FROM users WHERE id = ?'
    )
      .bind(recipientId)
      .first();
    
    if (!recipient) {
      return NextResponse.json(
        { error: 'Recipient not found' },
        { status: 404 }
      );
    }
    
    // Create message
    const messageId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'INSERT INTO messages (id, sender_id, recipient_id, content, read, created_at) VALUES (?, ?, ?, ?, ?, ?)'
    )
      .bind(messageId, userId, recipientId, content, 0, timestamp)
      .run();
    
    // Get sender info
    const sender = await env.DB.prepare(
      'SELECT username, display_name, avatar_url FROM users WHERE id = ?'
    )
      .bind(userId)
      .first();
    
    return NextResponse.json({
      message: 'Message sent',
      messageData: {
        id: messageId,
        senderId: userId,
        recipientId,
        content,
        read: 0,
        createdAt: timestamp,
        senderUsername: sender.username,
        senderDisplayName: sender.display_name,
        senderAvatarUrl: sender.avatar_url
      }
    }, { status: 201 });
  } catch (error) {
    console.error('Send message error:', error);
    return NextResponse.json(
      { error: 'Failed to send message' },
      { status: 500 }
    );
  }
}
