import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;

    // Get user profile
    const user = await env.DB.prepare(
      `SELECT u.id, u.username, u.email, u.display_name, u.avatar_url, u.created_at,
              p.location, p.interests, p.website, p.theme_preference, p.privacy_settings, p.last_active
       FROM users u
       LEFT JOIN profiles p ON u.id = p.user_id
       WHERE u.id = ?`
    )
      .bind(userId)
      .first();

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.display_name,
        avatarUrl: user.avatar_url,
        createdAt: user.created_at,
        profile: {
          location: user.location,
          interests: user.interests,
          website: user.website,
          themePreference: user.theme_preference,
          privacySettings: user.privacy_settings,
          lastActive: user.last_active
        }
      }
    });
  } catch (error) {
    console.error('Profile error:', error);
    return NextResponse.json(
      { error: 'Failed to get profile' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const { displayName, bio, location, interests, website, themePreference, privacySettings } = await request.json();
    const timestamp = Math.floor(Date.now() / 1000);

    // Update user
    await env.DB.prepare(
      'UPDATE users SET display_name = ?, bio = ?, updated_at = ? WHERE id = ?'
    )
      .bind(displayName, bio, timestamp, userId)
      .run();

    // Update profile
    await env.DB.prepare(
      'UPDATE profiles SET location = ?, interests = ?, website = ?, theme_preference = ?, privacy_settings = ?, updated_at = ? WHERE user_id = ?'
    )
      .bind(location, interests, website, themePreference, privacySettings, timestamp, userId)
      .run();

    return NextResponse.json({
      message: 'Profile updated successfully',
      user: {
        id: userId,
        displayName,
        bio,
        profile: {
          location,
          interests,
          website,
          themePreference,
          privacySettings
        }
      }
    });
  } catch (error) {
    console.error('Profile update error:', error);
    return NextResponse.json(
      { error: 'Failed to update profile' },
      { status: 500 }
    );
  }
}
