import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';

interface Env {
  DB: D1Database;
}

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    const { username, email, password, displayName } = await request.json();

    // Validate input
    if (!username || !email || !password) {
      return NextResponse.json(
        { error: 'Username, email, and password are required' },
        { status: 400 }
      );
    }

    // Check if username or email already exists
    const existingUser = await env.DB.prepare(
      'SELECT * FROM users WHERE username = ? OR email = ?'
    )
      .bind(username, email)
      .first();

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username or email already exists' },
        { status: 409 }
      );
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Create user
    const userId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);

    await env.DB.prepare(
      'INSERT INTO users (id, username, email, password_hash, display_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
      .bind(userId, username, email, passwordHash, displayName || username, timestamp, timestamp)
      .run();

    // Create profile
    await env.DB.prepare(
      'INSERT INTO profiles (user_id, created_at, updated_at) VALUES (?, ?, ?)'
    )
      .bind(userId, timestamp, timestamp)
      .run();

    return NextResponse.json(
      {
        message: 'User registered successfully',
        user: {
          id: userId,
          username,
          email,
          displayName: displayName || username,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Failed to register user' },
      { status: 500 }
    );
  }
}
