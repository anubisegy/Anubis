import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

interface Env {
  DB: D1Database;
}

// This would be stored in an environment variable in production
const JWT_SECRET = 'anubis-community-secret-key';

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    const { username, password } = await request.json();

    // Validate input
    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      );
    }

    // Find user by username
    const user = await env.DB.prepare(
      'SELECT * FROM users WHERE username = ?'
    )
      .bind(username)
      .first();

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    // Update last active timestamp in profile
    const timestamp = Math.floor(Date.now() / 1000);
    await env.DB.prepare(
      'UPDATE profiles SET last_active = ?, updated_at = ? WHERE user_id = ?'
    )
      .bind(timestamp, timestamp, user.id)
      .run();

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user.id,
        username: user.username,
        email: user.email
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return NextResponse.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.display_name,
        avatar: user.avatar_url
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Failed to login' },
      { status: 500 }
    );
  }
}
