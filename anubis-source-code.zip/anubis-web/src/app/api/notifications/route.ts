import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    
    // Get query parameters
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit') || '20');
    const offset = parseInt(url.searchParams.get('offset') || '0');
    
    // Get notifications for user
    const notifications = await env.DB.prepare(`
      SELECT n.*, 
             u.username, u.display_name, u.avatar_url
      FROM notifications n
      LEFT JOIN users u ON n.related_id = u.id
      WHERE n.user_id = ?
      ORDER BY n.created_at DESC
      LIMIT ? OFFSET ?
    `)
      .bind(userId, limit, offset)
      .all();
    
    // Mark notifications as read
    await env.DB.prepare(
      'UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0'
    )
      .bind(userId)
      .run();
    
    return NextResponse.json({ notifications: notifications.results });
  } catch (error) {
    console.error('Get notifications error:', error);
    return NextResponse.json(
      { error: 'Failed to get notifications' },
      { status: 500 }
    );
  }
}

// Helper function to create a notification
export async function createNotification(
  env: Env,
  userId: string,
  type: string,
  content: string,
  relatedId?: string
) {
  try {
    const notificationId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'INSERT INTO notifications (id, user_id, type, content, related_id, read, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
      .bind(notificationId, userId, type, content, relatedId || null, 0, timestamp)
      .run();
    
    return {
      id: notificationId,
      userId,
      type,
      content,
      relatedId,
      read: 0,
      createdAt: timestamp
    };
  } catch (error) {
    console.error('Create notification error:', error);
    return null;
  }
}
