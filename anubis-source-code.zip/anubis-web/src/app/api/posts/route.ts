import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Get query parameters
    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const offset = parseInt(url.searchParams.get('offset') || '0');
    
    // Construct query
    let query = `
      SELECT p.*, u.username, u.display_name, u.avatar_url,
             (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
             (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count
      FROM posts p
      JOIN users u ON p.user_id = u.id
      WHERE p.visibility = 'public'
    `;
    
    const queryParams = [];
    
    // Filter by user if provided
    if (userId) {
      query += ` AND p.user_id = ?`;
      queryParams.push(userId);
    }
    
    // Add ordering and pagination
    query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    queryParams.push(limit, offset);
    
    // Execute query
    const posts = await env.DB.prepare(query)
      .bind(...queryParams)
      .all();
    
    return NextResponse.json({ posts: posts.results });
  } catch (error) {
    console.error('Get posts error:', error);
    return NextResponse.json(
      { error: 'Failed to get posts' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const { content, imageUrl, visibility = 'public' } = await request.json();
    
    // Validate input
    if (!content && !imageUrl) {
      return NextResponse.json(
        { error: 'Post must contain content or image' },
        { status: 400 }
      );
    }
    
    // Create post
    const postId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'INSERT INTO posts (id, user_id, content, image_url, visibility, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
      .bind(postId, userId, content, imageUrl, visibility, timestamp, timestamp)
      .run();
    
    // Get user info
    const user = await env.DB.prepare(
      'SELECT username, display_name, avatar_url FROM users WHERE id = ?'
    )
      .bind(userId)
      .first();
    
    return NextResponse.json({
      message: 'Post created successfully',
      post: {
        id: postId,
        userId,
        content,
        imageUrl,
        visibility,
        createdAt: timestamp,
        updatedAt: timestamp,
        username: user.username,
        displayName: user.display_name,
        avatarUrl: user.avatar_url,
        likesCount: 0,
        commentsCount: 0
      }
    }, { status: 201 });
  } catch (error) {
    console.error('Create post error:', error);
    return NextResponse.json(
      { error: 'Failed to create post' },
      { status: 500 }
    );
  }
}
