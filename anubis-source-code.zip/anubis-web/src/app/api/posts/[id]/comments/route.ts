import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function POST(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const postId = params.id;
    const { content } = await request.json();
    
    // Validate input
    if (!content) {
      return NextResponse.json(
        { error: 'Comment content is required' },
        { status: 400 }
      );
    }
    
    // Check if post exists
    const post = await env.DB.prepare(
      'SELECT * FROM posts WHERE id = ?'
    )
      .bind(postId)
      .first();
    
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }
    
    // Create comment
    const commentId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'INSERT INTO comments (id, post_id, user_id, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    )
      .bind(commentId, postId, userId, content, timestamp, timestamp)
      .run();
    
    // Get user info
    const user = await env.DB.prepare(
      'SELECT username, display_name, avatar_url FROM users WHERE id = ?'
    )
      .bind(userId)
      .first();
    
    return NextResponse.json({
      message: 'Comment added successfully',
      comment: {
        id: commentId,
        postId,
        userId,
        content,
        createdAt: timestamp,
        updatedAt: timestamp,
        username: user.username,
        displayName: user.display_name,
        avatarUrl: user.avatar_url,
        likesCount: 0
      }
    }, { status: 201 });
  } catch (error) {
    console.error('Add comment error:', error);
    return NextResponse.json(
      { error: 'Failed to add comment' },
      { status: 500 }
    );
  }
}
