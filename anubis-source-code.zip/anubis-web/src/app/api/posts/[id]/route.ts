import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    const postId = params.id;
    
    // Get post with user info
    const post = await env.DB.prepare(`
      SELECT p.*, u.username, u.display_name, u.avatar_url,
             (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as likes_count,
             (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comments_count
      FROM posts p
      JOIN users u ON p.user_id = u.id
      WHERE p.id = ?
    `)
      .bind(postId)
      .first();
    
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }
    
    // Get comments for the post
    const comments = await env.DB.prepare(`
      SELECT c.*, u.username, u.display_name, u.avatar_url,
             (SELECT COUNT(*) FROM likes WHERE comment_id = c.id) as likes_count
      FROM comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.post_id = ?
      ORDER BY c.created_at ASC
    `)
      .bind(postId)
      .all();
    
    return NextResponse.json({
      post,
      comments: comments.results
    });
  } catch (error) {
    console.error('Get post error:', error);
    return NextResponse.json(
      { error: 'Failed to get post' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const postId = params.id;
    const { content, imageUrl, visibility } = await request.json();
    
    // Check if post exists and belongs to user
    const post = await env.DB.prepare(
      'SELECT * FROM posts WHERE id = ?'
    )
      .bind(postId)
      .first();
    
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }
    
    if (post.user_id !== userId) {
      return NextResponse.json(
        { error: 'Not authorized to update this post' },
        { status: 403 }
      );
    }
    
    // Update post
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'UPDATE posts SET content = ?, image_url = ?, visibility = ?, updated_at = ? WHERE id = ?'
    )
      .bind(content, imageUrl, visibility, timestamp, postId)
      .run();
    
    return NextResponse.json({
      message: 'Post updated successfully',
      post: {
        id: postId,
        userId,
        content,
        imageUrl,
        visibility,
        updatedAt: timestamp
      }
    });
  } catch (error) {
    console.error('Update post error:', error);
    return NextResponse.json(
      { error: 'Failed to update post' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const postId = params.id;
    
    // Check if post exists and belongs to user
    const post = await env.DB.prepare(
      'SELECT * FROM posts WHERE id = ?'
    )
      .bind(postId)
      .first();
    
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }
    
    if (post.user_id !== userId) {
      return NextResponse.json(
        { error: 'Not authorized to delete this post' },
        { status: 403 }
      );
    }
    
    // Delete post (comments and likes will be cascaded due to foreign key constraints)
    await env.DB.prepare(
      'DELETE FROM posts WHERE id = ?'
    )
      .bind(postId)
      .run();
    
    return NextResponse.json({
      message: 'Post deleted successfully'
    });
  } catch (error) {
    console.error('Delete post error:', error);
    return NextResponse.json(
      { error: 'Failed to delete post' },
      { status: 500 }
    );
  }
}
