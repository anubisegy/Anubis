import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function POST(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const postId = params.id;
    
    // Check if post exists
    const post = await env.DB.prepare(
      'SELECT * FROM posts WHERE id = ?'
    )
      .bind(postId)
      .first();
    
    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }
    
    // Check if user already liked the post
    const existingLike = await env.DB.prepare(
      'SELECT * FROM likes WHERE user_id = ? AND post_id = ?'
    )
      .bind(userId, postId)
      .first();
    
    if (existingLike) {
      // Unlike the post
      await env.DB.prepare(
        'DELETE FROM likes WHERE user_id = ? AND post_id = ?'
      )
        .bind(userId, postId)
        .run();
      
      return NextResponse.json({
        message: 'Post unliked successfully',
        liked: false
      });
    } else {
      // Like the post
      const likeId = uuidv4();
      const timestamp = Math.floor(Date.now() / 1000);
      
      await env.DB.prepare(
        'INSERT INTO likes (id, user_id, post_id, comment_id, created_at) VALUES (?, ?, ?, NULL, ?)'
      )
        .bind(likeId, userId, postId, timestamp)
        .run();
      
      return NextResponse.json({
        message: 'Post liked successfully',
        liked: true
      });
    }
  } catch (error) {
    console.error('Like post error:', error);
    return NextResponse.json(
      { error: 'Failed to like/unlike post' },
      { status: 500 }
    );
  }
}
