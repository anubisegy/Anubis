import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    
    // Get all connections for the user
    const connections = await env.DB.prepare(`
      SELECT c.*, 
             u.username, u.display_name, u.avatar_url
      FROM connections c
      JOIN users u ON c.connected_user_id = u.id
      WHERE c.user_id = ?
      ORDER BY c.updated_at DESC
    `)
      .bind(userId)
      .all();
    
    return NextResponse.json({ connections: connections.results });
  } catch (error) {
    console.error('Get connections error:', error);
    return NextResponse.json(
      { error: 'Failed to get connections' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest, { env }: { env: Env }) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const { connectedUserId } = await request.json();
    
    // Validate input
    if (!connectedUserId) {
      return NextResponse.json(
        { error: 'Connected user ID is required' },
        { status: 400 }
      );
    }
    
    // Check if user exists
    const connectedUser = await env.DB.prepare(
      'SELECT * FROM users WHERE id = ?'
    )
      .bind(connectedUserId)
      .first();
    
    if (!connectedUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Check if connection already exists
    const existingConnection = await env.DB.prepare(
      'SELECT * FROM connections WHERE user_id = ? AND connected_user_id = ?'
    )
      .bind(userId, connectedUserId)
      .first();
    
    if (existingConnection) {
      return NextResponse.json(
        { error: 'Connection already exists', connection: existingConnection },
        { status: 409 }
      );
    }
    
    // Create connection
    const connectionId = uuidv4();
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'INSERT INTO connections (id, user_id, connected_user_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    )
      .bind(connectionId, userId, connectedUserId, 'pending', timestamp, timestamp)
      .run();
    
    // Create reverse connection with pending status
    const reverseConnectionId = uuidv4();
    
    await env.DB.prepare(
      'INSERT INTO connections (id, user_id, connected_user_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    )
      .bind(reverseConnectionId, connectedUserId, userId, 'pending', timestamp, timestamp)
      .run();
    
    // Get user info
    const user = await env.DB.prepare(
      'SELECT username, display_name, avatar_url FROM users WHERE id = ?'
    )
      .bind(connectedUserId)
      .first();
    
    return NextResponse.json({
      message: 'Connection request sent',
      connection: {
        id: connectionId,
        userId,
        connectedUserId,
        status: 'pending',
        createdAt: timestamp,
        updatedAt: timestamp,
        username: user.username,
        displayName: user.display_name,
        avatarUrl: user.avatar_url
      }
    }, { status: 201 });
  } catch (error) {
    console.error('Create connection error:', error);
    return NextResponse.json(
      { error: 'Failed to create connection' },
      { status: 500 }
    );
  }
}
