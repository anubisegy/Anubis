import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { verifyAuth } from '@/lib/auth';

interface Env {
  DB: D1Database;
}

export async function PUT(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const connectionId = params.id;
    const { status } = await request.json();
    
    // Validate input
    if (!status || !['accepted', 'rejected', 'blocked'].includes(status)) {
      return NextResponse.json(
        { error: 'Valid status is required (accepted, rejected, or blocked)' },
        { status: 400 }
      );
    }
    
    // Check if connection exists and belongs to user
    const connection = await env.DB.prepare(
      'SELECT * FROM connections WHERE id = ? AND user_id = ?'
    )
      .bind(connectionId, userId)
      .first();
    
    if (!connection) {
      return NextResponse.json(
        { error: 'Connection not found or not authorized' },
        { status: 404 }
      );
    }
    
    // Update connection status
    const timestamp = Math.floor(Date.now() / 1000);
    
    await env.DB.prepare(
      'UPDATE connections SET status = ?, updated_at = ? WHERE id = ?'
    )
      .bind(status, timestamp, connectionId)
      .run();
    
    // If accepting, also update the reverse connection
    if (status === 'accepted') {
      await env.DB.prepare(
        'UPDATE connections SET status = ?, updated_at = ? WHERE user_id = ? AND connected_user_id = ?'
      )
        .bind(status, timestamp, connection.connected_user_id, userId)
        .run();
    }
    
    return NextResponse.json({
      message: `Connection ${status}`,
      connection: {
        id: connectionId,
        status,
        updatedAt: timestamp
      }
    });
  } catch (error) {
    console.error('Update connection error:', error);
    return NextResponse.json(
      { error: 'Failed to update connection' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params, env }: { params: { id: string }; env: Env }
) {
  try {
    // Verify authentication
    const authResult = await verifyAuth(request);
    if (!authResult.success) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const userId = authResult.userId;
    const connectionId = params.id;
    
    // Check if connection exists and belongs to user
    const connection = await env.DB.prepare(
      'SELECT * FROM connections WHERE id = ? AND user_id = ?'
    )
      .bind(connectionId, userId)
      .first();
    
    if (!connection) {
      return NextResponse.json(
        { error: 'Connection not found or not authorized' },
        { status: 404 }
      );
    }
    
    // Delete connection
    await env.DB.prepare(
      'DELETE FROM connections WHERE id = ?'
    )
      .bind(connectionId)
      .run();
    
    // Delete reverse connection
    await env.DB.prepare(
      'DELETE FROM connections WHERE user_id = ? AND connected_user_id = ?'
    )
      .bind(connection.connected_user_id, userId)
      .run();
    
    return NextResponse.json({
      message: 'Connection removed'
    });
  } catch (error) {
    console.error('Delete connection error:', error);
    return NextResponse.json(
      { error: 'Failed to delete connection' },
      { status: 500 }
    );
  }
}
